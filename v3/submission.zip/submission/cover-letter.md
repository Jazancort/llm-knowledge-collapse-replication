---
geometry: margin=2.5cm
fontsize: 12pt
mainfont: Times New Roman
---

Dear Editor-in-Chief,

We are pleased to submit our manuscript entitled "Effective Training Pressure Gates Recursive Knowledge Degradation in LLMs: A Multi-Axis Dose-Response Study" for consideration as a Research Paper in *Engineering Applications of Artificial Intelligence*.

Recursive fine-tuning on synthetic data is increasingly adopted in production pipelines, yet the conditions under which it preserves or degrades factual knowledge remain poorly characterized. Our study provides the first systematic dose-response analysis of recursive degradation under parameter-efficient fine-tuning (LoRA/QLoRA), spanning three backbone architectures, ten recursive generations, and multiple independent seeds per condition.

The key contribution is the identification of *effective training pressure* as an organizing principle: we demonstrate that recursive degradation is a pressure-gated phenomenon exhibiting a sharp regime transition from homeostatic retention to progressive knowledge loss. The transition threshold differs by an order of magnitude across architectures, is jointly determined by adapter rank and learning rate, and can be controlled through modest reductions in synthetic exposure. These findings provide actionable configuration guidelines for practitioners deploying recursive training pipelines.

We believe this work aligns well with the scope of EAAI, which emphasizes practical applications of AI methods across engineering domains. The paper offers both empirical characterization and directly applicable thresholds for safe recursive training configurations.

This manuscript has not been published elsewhere and is not under consideration by another journal. All authors have approved the manuscript and agree with its submission.

\vspace{1cm}

Sincerely,

**Julio Leite Azancort Neto** (corresponding author)\
On behalf of all co-authors:\
Carlos André de Mattos Teixeira, André Carlos Ponce de Leon Ferreira de Carvalho, Carlos Renato Lisboa Francês

Contact: julio.azancort.neto@itec.ufpa.br
